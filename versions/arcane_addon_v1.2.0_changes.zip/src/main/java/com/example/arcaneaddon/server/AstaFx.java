package com.example.arcaneaddon.server;

import com.example.arcaneaddon.ArcaneAddon;
import com.example.arcaneaddon.registry.AddonSpellRegistry;
import io.redspace.ironsspellbooks.api.entity.IMagicEntity;
import io.redspace.ironsspellbooks.api.magic.MagicData;
import io.redspace.ironsspellbooks.api.util.Utils;
import io.redspace.ironsspellbooks.damage.DamageSources;
import io.redspace.ironsspellbooks.damage.SpellDamageSource;
import com.example.arcaneaddon.registry.AddonItemRegistry;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.DustColorTransitionOptions;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

import java.util.Random;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Effects of the Asta-themed grimoire spells (Zetten, Sky Splitter, Anti Magic, Ki Sense, Instinct Guard, Devil Union). */
@Mod.EventBusSubscriber(modid = ArcaneAddon.MODID)
public class AstaFx {
    private static final DustParticleOptions CRIMSON = new DustParticleOptions(new Vector3f(0.8f, 0.05f, 0.1f), 1.6f);
    private static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.05f, 0.0f, 0.08f), 1.8f);
    private static final DustColorTransitionOptions EMBER = new DustColorTransitionOptions(new Vector3f(1f, 0.15f, 0.1f), new Vector3f(0.1f, 0f, 0.05f), 1.4f);

    private static final int GUARD_TICKS = 40;          // Instinct Guard: a 2 s counter stance
    private static final int COUNTER_GAP = 10;          // at most one counter every 0.5 s (also stops two guards countering each other forever)
    private static final double COUNTER_RANGE = 6.0;
    private static final Map<UUID, Long> LAST_COUNTER = new HashMap<>();
    private static final int UNION_TICKS = 50 * 20;     // Devil Union: 50 s, like the manga
    private static final float SWORD_SPELL_RESIST = 0.35f;   // holding a sword: 35% less spell damage
    private static final float UNION_SPELL_RESIST = 0.70f;   // Devil Union: 70% less spell damage
    private static final Map<UUID, Long> GUARD = new HashMap<>();
    private static final Map<UUID, Long> UNION = new HashMap<>();

    private static void sound(ServerLevel sl, Vec3 at, SoundEvent s, float vol, float pitch) {
        sl.playSound(null, at.x, at.y, at.z, s, SoundSource.PLAYERS, vol, pitch);
    }
    private static void burst(ServerLevel sl, ParticleOptions o, Vec3 c, int n, double sp, double spread) {
        sl.sendParticles(o, c.x, c.y, c.z, n, spread, spread, spread, sp);
    }
    private static void ring(ServerLevel sl, ParticleOptions o, Vec3 c, int n, double speed) {
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n;
            sl.sendParticles(o, c.x, c.y, c.z, 0, Math.cos(a), 0.0, Math.sin(a), speed);
        }
    }
    // ------------------------------------------------------------------ tiny scheduler for staged visuals
    private record Task(long due, Runnable run) {}
    private static final List<Task> TASKS = new ArrayList<>();
    private static long serverTicks = 0;

    /** Runs {@code r} on the server thread {@code ticks} ticks from now. Used to stage effects over time. */
    public static void later(int ticks, Runnable r) { TASKS.add(new Task(serverTicks + Math.max(1, ticks), r)); }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        serverTicks++;
        if (TASKS.isEmpty()) return;
        List<Task> due = new ArrayList<>();
        TASKS.removeIf(t -> { if (t.due() <= serverTicks) { due.add(t); return true; } return false; });
        for (Task t : due) {
            try { t.run().run(); } catch (Exception ex) { /* a visual must never crash the server */ }
        }
    }

    /** Cuts a ranged attack short at the first solid block, so beams and slashes no longer pass through walls. */
    private static Vec3 clipToBlocks(ServerLevel sl, ServerPlayer p, Vec3 start, Vec3 end) {
        var hit = sl.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return hit.getType() == HitResult.Type.MISS ? end : hit.getLocation();
    }

    /** True while the player is in Devil Union. */
    public static boolean inDevilUnion(ServerPlayer p) {
        Long u = UNION.get(p.getUUID());
        return u != null && p.level().getGameTime() <= u;
    }

    /** True when the player holds a Demon Slayer or Demon Dweller Sword in either hand. */
    public static boolean holdsAntiMagicSword(ServerPlayer p) {
        return p.getMainHandItem().is(AddonItemRegistry.DEMON_SLAYER_SWORD.get()) || p.getMainHandItem().is(AddonItemRegistry.DEMON_DWELLER_SWORD.get())
                || p.getOffhandItem().is(AddonItemRegistry.DEMON_SLAYER_SWORD.get()) || p.getOffhandItem().is(AddonItemRegistry.DEMON_DWELLER_SWORD.get());
    }

    public static boolean isDweller(ServerPlayer p) { return p.getMainHandItem().is(com.example.arcaneaddon.registry.AddonItemRegistry.DEMON_DWELLER_SWORD.get()); }

    static void damage(ServerPlayer p, LivingEntity t, float dmg, String id) {
        var spell = AddonSpellRegistry.SPELLS.getEntries().stream().filter(e -> e.getId().getPath().equals(id)).findFirst().map(e -> e.get()).orElse(null);
        if (spell != null) DamageSources.applyDamage(t, dmg, spell.getDamageSource(p));
        else t.hurt(p.damageSources().playerAttack(p), dmg);
    }

    private static void variantMsg(ServerPlayer p) {
        p.displayClientMessage(Component.translatable("ui.arcane_addon.variant.dweller").withStyle(ChatFormatting.DARK_PURPLE), true);
    }

    // ------------------------------------------------------------------ Zetten: huge downward slash (Slayer) / fast X of two slashes (Dweller)
    public static void zetten(ServerPlayer p, float dmg, boolean dw) {
        ServerLevel sl = p.serverLevel();
        if (dw) { dmg *= 0.85f; variantMsg(p); }
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0, look.z).normalize();
        Vec3 center = p.position().add(dir.scale(2.6));
        List<LivingEntity> targets = sl.getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(dw ? 3.8 : 3.2, 2.5, dw ? 3.8 : 3.2),
                t -> t != p && t.isAlive() && !t.isAlliedTo(p) && t.position().subtract(p.position()).multiply(1, 0, 1).normalize().dot(dir) > 0.2);
        for (LivingEntity t : targets) {
            damage(p, t, dmg, "zetten");
            t.knockback(1.2, -dir.x, -dir.z);
            Vec3 m = t.position().add(0, t.getBbHeight() * 0.5, 0);
            burst(sl, ParticleTypes.CRIT, m, 18, 0.5, 0.4);
            burst(sl, ParticleTypes.EXPLOSION, m, 1, 0, 0);
        }
        Vec3 rt = dir.cross(new Vec3(0, 1, 0)).normalize();
        if (dw) {   // two diagonal dark blades crossing in an X
            Vec3 cx = eye.add(dir.scale(2.4)).add(0, -0.2, 0);
            for (int dgn = 0; dgn < 2; dgn++) {
                Vec3 u = rt.scale(dgn == 0 ? 0.7 : -0.7).add(0, 0.7, 0).scale(3.0);
                FxSend.beam(sl, 1, cx.subtract(u), cx.add(u), 0.55f, 9);
            }
            FxSend.wall(sl, 1, p.position().add(0, 0.1, 0).add(dir.scale(0.2)), dir, rt, 3.4f, 3.4f, -70, 70, 0.8f, 8, 2, 0);
        } else {    // the Slayer's vertical cleave, from above your head down to the ground
            FxSend.wall(sl, 0, eye.add(0, -0.3, 0), dir, new Vec3(0, 1, 0), 3.4f, 3.4f, 80, -70, 1.5f, 13, 3, 0);
        }
        Vec3 hit = p.position().add(dir.scale(3.2)).add(0, 0.1, 0);
        FxSend.ring(sl, 6, p.position().add(0, 0.05, 0), 0.2f, 1.6f, 0.2f, 6);   // charge glint at your feet
        FxSend.ring(sl, dw ? 1 : 0, hit, 0.4f, 4.5f, 0.45f, 10);
        // two staggered shockwaves rolling out of the impact
        later(2, () -> FxSend.ring(sl, 6, hit, 0.5f, 6.0f, 0.25f, 8));
        later(4, () -> FxSend.ring(sl, dw ? 1 : 0, hit, 1.0f, 7.5f, 0.15f, 8));
        if (dw) {
            // afterimage of the X, a beat later
            Vec3 cx = eye.add(dir.scale(2.4)).add(0, -0.2, 0);
            later(2, () -> {
                for (int dgn = 0; dgn < 2; dgn++) {
                    Vec3 u2 = rt.scale(dgn == 0 ? 0.7 : -0.7).add(0, 0.7, 0).scale(3.3);
                    FxSend.beam(sl, 6, cx.subtract(u2), cx.add(u2), 0.2f, 7);
                }
            });
        } else {
            // the ground splits open in a line ahead of the cut
            burst(sl, ParticleTypes.SONIC_BOOM, hit.add(0, 0.6, 0), 1, 0, 0);
            Vec3 ground = new Vec3(hit.x, p.getY() + 0.05, hit.z);
            for (int i = 1; i <= 4; i++) {
                final int seg = i;
                later(seg, () -> {
                    Vec3 a = ground.add(dir.scale((seg - 1) * 1.6)), b = ground.add(dir.scale(seg * 1.6));
                    FxSend.beam(sl, 0, a, b, 0.35f, 14);
                    burst(sl, BLACK, b.add(0, 0.2, 0), 8, 0.05, 0.3);
                    burst(sl, ParticleTypes.LARGE_SMOKE, b.add(0, 0.2, 0), 3, 0.02, 0.2);
                    sound(sl, b, SoundEvents.STONE_BREAK, 0.7f, 0.6f);
                });
            }
        }
        burst(sl, ParticleTypes.EXPLOSION, hit.add(0, 0.4, 0), 2, 0, 0.5);
        sound(sl, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.5f);
        sound(sl, hit, SoundEvents.GENERIC_EXPLODE, 0.8f, 1.2f);
        sound(sl, hit, SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.6f);
    }

    // ------------------------------------------------------------------ Sky Splitter: ranged beam that cleaves everything in a line (Dweller: twin beams)
    public static void skySplitter(ServerPlayer p, float dmg, boolean dw) {
        ServerLevel sl = p.serverLevel();
        if (dw) { dmg *= 0.85f; variantMsg(p); }
        Vec3 start = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        double len = 26;
        Vec3 end = clipToBlocks(sl, p, start, start.add(dir.scale(len)));
        List<LivingEntity> hit = new ArrayList<>();
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, new AABB(start, end).inflate(2.5), x -> x != p && x.isAlive() && !x.isAlliedTo(p))) {
            if (t.getBoundingBox().inflate(1.1).clip(start, end).isPresent()) hit.add(t);
        }
        for (LivingEntity t : hit) {
            damage(p, t, dmg, "sky_splitter");
            Vec3 m = t.position().add(0, t.getBbHeight() * 0.5, 0);
            burst(sl, ParticleTypes.CRIT, m, 24, 0.6, 0.4);
            burst(sl, ParticleTypes.EXPLOSION, m, 1, 0, 0);
            sound(sl, t.position(), SoundEvents.PLAYER_ATTACK_STRONG, 1f, 0.6f);
        }
        if (end.distanceToSqr(start) < len * len - 0.01) {   // the beam bit into a wall
            burst(sl, ParticleTypes.EXPLOSION, end, 1, 0, 0);
            burst(sl, BLACK, end, 20, 0.2, 0.4);
        }
        Vec3 rt = dir.cross(new Vec3(0, 1, 0));
        rt = rt.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : rt.normalize();
        Vec3 from = start.add(dir.scale(1.0)).add(0, -0.25, 0);
        if (dw) {
            for (int side = -1; side <= 1; side += 2) FxSend.beam(sl, 1, from.add(rt.scale(side * 0.9)), end.add(rt.scale(side * 0.9)), 0.75f, 12);
        } else {
            FxSend.beam(sl, 0, from, end, 1.25f, 12);
            FxSend.beam(sl, 6, from, end, 0.5f, 9);
        }
        FxSend.ring(sl, dw ? 1 : 0, start.add(dir.scale(1.2)), 0.2f, 1.6f, 0.3f, 6);
        burst(sl, ParticleTypes.FLASH, from, 1, 0, 0);
        // a thin silver afterimage that lingers once the main beam fades
        final Vec3 rtF = rt, endF = end;
        later(3, () -> {
            if (dw) for (int side = -1; side <= 1; side += 2) FxSend.beam(sl, 6, from.add(rtF.scale(side * 0.9)), endF.add(rtF.scale(side * 0.9)), 0.22f, 8);
            else FxSend.beam(sl, 6, from, endF, 0.3f, 9);
        });
        // sparks racing down the cut, from the sword out to the end
        double dist = from.distanceTo(end);
        int steps = Math.min(13, (int) (dist / 2));
        for (int i = 1; i <= steps; i++) {
            final Vec3 at = from.add(dir.scale(i * 2.0));
            later(1 + i / 3, () -> {
                burst(sl, ParticleTypes.SWEEP_ATTACK, at, 1, 0, 0);
                burst(sl, BLACK, at, 4, 0.03, 0.2);
            });
        }
        if (end.distanceToSqr(start) < len * len - 0.01) {
            later(1 + steps / 3, () -> {
                burst(sl, ParticleTypes.SONIC_BOOM, endF, 1, 0, 0);
                FxSend.ring(sl, dw ? 1 : 0, endF, 0.3f, 3.0f, 0.4f, 8);
            });
        }
        sound(sl, p.position(), SoundEvents.LIGHTNING_BOLT_THUNDER, 0.6f, 1.6f);
        sound(sl, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.4f);
        sound(sl, p.position(), SoundEvents.TRIDENT_THUNDER, 0.8f, 1.3f);
    }

    // ------------------------------------------------------------------ Demon Dweller Sword: projected slash of anti magic
    private static final Random RND = new Random();
    private static final String[] ELEMENTS = {"fire", "ice", "lightning", "wind"};

    /** borrowed=false: pure anti magic crescent that also strips effects. borrowed=true: it takes on a random element. */
    public static void dwellerSlash(ServerPlayer p, float dmg, boolean borrowed) {
        ServerLevel sl = p.serverLevel();
        Vec3 start = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double len = 20;
        Vec3 end = clipToBlocks(sl, p, start, start.add(look.scale(len)));
        String el = borrowed ? ELEMENTS[RND.nextInt(ELEMENTS.length)] : null;
        int pal = el == null ? 1 : switch (el) { case "fire" -> 2; case "ice" -> 3; case "lightning" -> 4; default -> 5; };
        ParticleOptions spark = el == null ? ParticleTypes.SOUL_FIRE_FLAME : switch (el) {
            case "fire" -> ParticleTypes.FLAME;
            case "ice" -> ParticleTypes.SNOWFLAKE;
            case "lightning" -> ParticleTypes.ELECTRIC_SPARK;
            default -> ParticleTypes.CLOUD;
        };
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, new AABB(start, end).inflate(2.5), x -> x != p && x.isAlive() && !x.isAlliedTo(p))) {
            if (!t.getBoundingBox().inflate(1.3).clip(start, end).isPresent()) continue;
            float d = dmg;
            if ("lightning".equals(el)) d += 4;
            damage(p, t, d, borrowed ? "borrowed_slash" : "dweller_slash");
            Vec3 c = t.position().add(0, t.getBbHeight() * 0.5, 0);
            if (el == null) t.removeAllEffects();   // anti magic
            else switch (el) {
                case "fire" -> t.setSecondsOnFire(6);
                case "ice" -> { t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80, 2)); t.setTicksFrozen(t.getTicksRequiredToFreeze() + 60); }
                case "lightning" -> sound(sl, c, SoundEvents.LIGHTNING_BOLT_THUNDER, 0.5f, 1.8f);
                default -> t.push(0, 0.9, 0);
            }
            burst(sl, spark, c, 14, 0.15, 0.4);
            burst(sl, ParticleTypes.CRIT, c, 16, 0.5, 0.4);
            sound(sl, c, SoundEvents.PLAYER_ATTACK_CRIT, 1f, 1.3f);
        }
        // the flying crescent blade: a real 3D mesh, tilted 30 degrees like a diagonal cut
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 up = right.cross(look).normalize();
        double tilt = Math.toRadians(30);
        Vec3 u = right.scale(Math.cos(tilt)).add(up.scale(Math.sin(tilt)));
        Vec3 cStart = start.add(look.scale(1.6)).add(0, -0.2, 0);
        FxSend.crescent(sl, pal, cStart, look, u, 1.3f, 2.6f, 9, 2.4f);
        // a pale echo blade chases the first one
        later(2, () -> FxSend.crescent(sl, el == null ? 6 : pal, cStart, look, u, 1.0f, 2.0f, 7, 2.4f));
        burst(sl, ParticleTypes.FLASH, cStart, 1, 0, 0);
        FxSend.ring(sl, pal, start.add(look.scale(1.2)), 0.2f, 1.4f, 0.3f, 6);
        sound(sl, p.position(), SoundEvents.PLAYER_ATTACK_SWEEP, 1.2f, 0.7f);
        sound(sl, p.position(), SoundEvents.TRIDENT_RIPTIDE_1, 0.7f, 1.4f);
        if (el != null) {
            sound(sl, p.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 0.8f, 1.4f);
            p.displayClientMessage(Component.translatable("ui.arcane_addon.borrowed." + el).withStyle(ChatFormatting.DARK_RED), true);
        }
    }

    // ------------------------------------------------------------------ Anti Magic: strips every magical effect around you
    public static void antiMagic(ServerPlayer p) {
        ServerLevel sl = p.serverLevel();
        new ArrayList<>(p.getActiveEffects()).stream().filter(e -> !e.getEffect().isBeneficial()).forEach(e -> p.removeEffect(e.getEffect()));
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(9), x -> x != p && x.isAlive() && !x.isAlliedTo(p))) {
            if (!t.getActiveEffects().isEmpty()) t.removeAllEffects();
            // anti magic also breaks any spell being cast nearby
            if (t instanceof ServerPlayer sp && MagicData.getPlayerMagicData(sp).isCasting()) {
                Utils.serverSideCancelCast(sp);
                burst(sl, ParticleTypes.ENCHANTED_HIT, sp.position().add(0, 1, 0), 25, 0.4, 0.4);
                sound(sl, sp.position(), SoundEvents.GLASS_BREAK, 1f, 0.7f);
                sp.displayClientMessage(Component.translatable("ui.arcane_addon.cast_broken").withStyle(ChatFormatting.DARK_RED), true);
            } else if (t instanceof IMagicEntity mage && mage.isCasting()) {
                mage.cancelCast();
                burst(sl, ParticleTypes.ENCHANTED_HIT, t.position().add(0, 1, 0), 25, 0.4, 0.4);
                sound(sl, t.position(), SoundEvents.GLASS_BREAK, 1f, 0.7f);
            }
            burst(sl, ParticleTypes.CRIT, t.position().add(0, t.getBbHeight() * 0.5, 0), 10, 0.3, 0.4);
        }
        Vec3 c = p.position().add(0, 0.1, 0);
        FxSend.ring(sl, 6, c, 0.5f, 9.5f, 1.3f, 12);
        FxSend.ring(sl, 1, c.add(0, 0.5, 0), 0.3f, 7f, 0.9f, 10);
        FxSend.ring(sl, 0, c.add(0, 1.0, 0), 0.2f, 5f, 0.6f, 8);
        // a black pillar of anti magic, then two more waves rolling outward
        FxSend.beam(sl, 1, c, c.add(0, 7, 0), 0.9f, 12);
        FxSend.beam(sl, 6, c, c.add(0, 7.5, 0), 0.3f, 10);
        later(3, () -> FxSend.ring(sl, 6, c, 0.5f, 11f, 0.6f, 10));
        later(6, () -> FxSend.ring(sl, 1, c, 0.5f, 12.5f, 0.3f, 10));
        later(3, () -> sound(sl, c, SoundEvents.ILLUSIONER_CAST_SPELL, 1f, 0.6f));
        sound(sl, p.position(), SoundEvents.BEACON_DEACTIVATE, 1.2f, 0.6f);
        sound(sl, p.position(), SoundEvents.ENCHANTMENT_TABLE_USE, 1f, 0.5f);
    }

    // ------------------------------------------------------------------ Ki Sense: everything nearby is revealed
    public static void kiSense(ServerPlayer p) {
        ServerLevel sl = p.serverLevel();
        for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(32), x -> x != p && x.isAlive())) {
            t.addEffect(new MobEffectInstance(MobEffects.GLOWING, 12 * 20, 0, false, false));
        }
        Vec3 c = p.position().add(0, 0.1, 0);
        FxSend.ring(sl, 0, c, 0.5f, 32f, 0.7f, 16);
        FxSend.ring(sl, 6, c.add(0, 0.4, 0), 0.3f, 22f, 0.5f, 12);
        // two more sonar pings, each one higher in pitch
        for (int k = 1; k <= 2; k++) {
            final float pitch = 1.0f + k * 0.35f;
            later(k * 6, () -> {
                FxSend.ring(sl, 6, c, 0.5f, 32f, 0.4f, 16);
                sound(sl, c, SoundEvents.AMETHYST_BLOCK_CHIME, 1.2f, pitch);
            });
        }
        sound(sl, p.position(), SoundEvents.BEACON_ACTIVATE, 1f, 1.6f);
        sound(sl, p.position(), SoundEvents.AMETHYST_BLOCK_RESONATE, 1f, 0.7f);
    }

    // ------------------------------------------------------------------ Instinct Guard: a moment where nothing can touch you
    public static void instinct(ServerPlayer p) {
        ServerLevel sl = p.serverLevel();
        GUARD.put(p.getUUID(), sl.getGameTime() + GUARD_TICKS);
        LAST_COUNTER.remove(p.getUUID());
        FxSend.ring(sl, 6, p.position().add(0, 0.9, 0), 0.4f, 2.4f, 1.0f, 9);
        FxSend.ring(sl, 0, p.position().add(0, 0.2, 0), 0.4f, 2.0f, 0.5f, 8);
        FxSend.ring(sl, 6, p.position().add(0, 0.05, 0), 0.3f, 6.0f, 0.15f, 10);   // ki spreads out to read the next attack
        burst(sl, ParticleTypes.END_ROD, p.position().add(0, 1, 0), 16, 0.05, 0.6);
        sound(sl, p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.8f, 1.6f);
        sound(sl, p.position(), SoundEvents.AMETHYST_BLOCK_CHIME, 1f, 1.8f);
    }

    /** Instinct Guard counter: step behind the attacker and cut them before they recover. */
    private static void counter(ServerPlayer p, LivingEntity attacker) {
        ServerLevel sl = p.serverLevel();
        Vec3 from = p.position();
        Vec3 a = attacker.position();
        Vec3 through = a.subtract(from).multiply(1, 0, 1);
        if (through.lengthSqr() < 1.0E-4) through = attacker.getLookAngle().multiply(-1, 0, -1);
        through = through.normalize();
        Vec3 dest = a.add(through.scale(attacker.getBbWidth() * 0.5 + 1.0));
        // only blink if there is room behind them
        if (sl.noCollision(p, p.getBoundingBox().move(dest.subtract(from)))) {
            float yaw = (float) (Mth.atan2(a.z - dest.z, a.x - dest.x) * (180.0 / Math.PI)) - 90f;
            p.connection.teleport(dest.x, dest.y, dest.z, yaw, p.getXRot());
            p.resetFallDistance();
            FxSend.beam(sl, 6, from.add(0, 1, 0), dest.add(0, 1, 0), 0.25f, 8);   // afterimage trail of the blink
            burst(sl, ParticleTypes.LARGE_SMOKE, from.add(0, 1, 0), 8, 0.02, 0.3);
        }
        float power = (float) p.getAttributeValue(io.redspace.ironsspellbooks.api.registry.AttributeRegistry.SPELL_POWER.get());
        damage(p, attacker, 12f * power, "instinct_guard");
        attacker.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 1));
        attacker.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 40, 0));
        Vec3 m = attacker.position().add(0, attacker.getBbHeight() * 0.5, 0);
        Vec3 look = m.subtract(p.getEyePosition());
        look = look.lengthSqr() < 1.0E-4 ? p.getLookAngle() : look.normalize();
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
        Vec3 up = right.cross(look).normalize();
        Vec3 u = right.scale(Math.cos(Math.toRadians(-35))).add(up.scale(Math.sin(Math.toRadians(-35))));
        FxSend.crescent(sl, 0, m.subtract(look.scale(0.8)), look, u, 1.1f, 1.9f, 6, 0.4f);
        burst(sl, ParticleTypes.FLASH, m, 1, 0, 0);
        burst(sl, CRIMSON, m, 24, 0.15, 0.4);
        burst(sl, ParticleTypes.SWEEP_ATTACK, m, 2, 0, 0.3);
        sound(sl, m, SoundEvents.ENDERMAN_TELEPORT, 0.7f, 1.8f);
        sound(sl, m, SoundEvents.PLAYER_ATTACK_CRIT, 1.2f, 0.7f);
        sound(sl, m, SoundEvents.TRIDENT_HIT, 1f, 0.6f);
        p.displayClientMessage(Component.translatable("ui.arcane_addon.counter").withStyle(ChatFormatting.RED, ChatFormatting.BOLD), true);
    }

    // ------------------------------------------------------------------ Devil Union: Liebe merges with you for 50 seconds
    public static void devilUnion(ServerPlayer p) {
        ServerLevel sl = p.serverLevel();
        UNION.put(p.getUUID(), sl.getGameTime() + UNION_TICKS);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, UNION_TICKS, 2, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, UNION_TICKS, 2, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, UNION_TICKS, 1, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, UNION_TICKS, 1, false, false));
        p.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, UNION_TICKS, 1, false, false));
        Vec3 c = p.position();
        FxSend.ring(sl, 1, c.add(0, 0.1, 0), 0.4f, 7f, 1.6f, 16);
        FxSend.ring(sl, 0, c.add(0, 0.6, 0), 0.3f, 5f, 1.2f, 14);
        FxSend.ring(sl, 1, c.add(0, 1.2, 0), 0.2f, 4f, 0.9f, 12);
        burst(sl, ParticleTypes.LARGE_SMOKE, c.add(0, 1, 0), 24, 0.08, 0.6);
        // four black pillars rise around you, then the union bursts outward and shoves enemies back
        later(4, () -> {
            for (int k = 0; k < 4; k++) {
                double a = k * Math.PI / 2 + Math.PI / 4;
                Vec3 base = c.add(Math.cos(a) * 1.6, 0, Math.sin(a) * 1.6);
                FxSend.beam(sl, 1, base, base.add(0, 4.5, 0), 0.5f, 12);
            }
            sound(sl, c, SoundEvents.SOUL_ESCAPE, 1.2f, 0.5f);
        });
        later(8, () -> {
            FxSend.ring(sl, 1, c.add(0, 0.2, 0), 0.5f, 9f, 0.35f, 12);
            FxSend.ring(sl, 6, c.add(0, 0.6, 0), 0.5f, 6f, 0.25f, 10);
            burst(sl, ParticleTypes.EXPLOSION, c.add(0, 1, 0), 3, 0, 0.8);
            burst(sl, BLACK, c.add(0, 1, 0), 60, 0.25, 1.0);
            sound(sl, c, SoundEvents.GENERIC_EXPLODE, 0.9f, 0.5f);
            if (p.isAlive()) {
                for (LivingEntity t : sl.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(6), x -> x != p && x.isAlive() && !x.isAlliedTo(p))) {
                    Vec3 away = t.position().subtract(p.position()).multiply(1, 0, 1);
                    if (away.lengthSqr() < 1.0E-4) away = new Vec3(1, 0, 0);
                    away = away.normalize();
                    t.knockback(1.6, -away.x, -away.z);
                }
            }
        });
        sound(sl, c, SoundEvents.WITHER_SPAWN, 0.5f, 1.6f);
        sound(sl, c, SoundEvents.ENDER_DRAGON_GROWL, 0.6f, 0.7f);
        sound(sl, c, SoundEvents.BEACON_POWER_SELECT, 1f, 0.5f);
    }

    // ------------------------------------------------------------------ events
    @SubscribeEvent
    public static void onAttack(LivingAttackEvent e) {
        if (e.getSource().is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;   // /kill, the void
        if (e.getEntity() instanceof ServerPlayer p) {
            Long until = GUARD.get(p.getUUID());
            if (until != null) {
                if (p.level().getGameTime() <= until) {
                    e.setCanceled(true);
                    ServerLevel sl = p.serverLevel();
                    burst(sl, ParticleTypes.CRIT, p.position().add(0, 1, 0), 15, 0.5, 0.4);
                    sound(sl, p.position(), SoundEvents.SHIELD_BLOCK, 0.8f, 1.5f);
                    Entity src = e.getSource().getEntity();
                    if (src instanceof LivingEntity attacker && attacker != p && attacker.isAlive() && attacker.distanceTo(p) <= COUNTER_RANGE) {
                        long now = sl.getGameTime();
                        Long last = LAST_COUNTER.get(p.getUUID());
                        if (last == null || now - last >= COUNTER_GAP) {
                            LAST_COUNTER.put(p.getUUID(), now);   // set first: stops two guarding players countering forever
                            counter(p, attacker);
                        }
                    }
                } else GUARD.remove(p.getUUID());
            }
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        ServerLevel sl = p.serverLevel();
        long now = sl.getGameTime();
        Long g = GUARD.get(p.getUUID());
        if (g != null) {
            if (now > g) GUARD.remove(p.getUUID());
            else {
                // ki outline around the body while the stance is up
                if (now % 4 == 0) FxSend.wall(sl, 6, p.position().add(0, 1.0, 0), new Vec3(1, 0, 0), new Vec3(0, 0, 1), 0.75f, 0.9f, -180, 180, 1.0f, 6, 0, 0);
                if (now % 2 == 0) {
                    double a = now * 0.6;
                    burst(sl, ParticleTypes.END_ROD, p.position().add(Math.cos(a) * 0.9, 1.0 + Math.sin(a * 0.5) * 0.5, Math.sin(a) * 0.9), 1, 0, 0);
                }
            }
        }
        Long u = UNION.get(p.getUUID());
        if (u != null) {
            if (now > u) {
                UNION.remove(p.getUUID());
                ring(sl, BLACK, p.position().add(0, 0.2, 0), 30, 0.3);
                sound(sl, p.position(), SoundEvents.BEACON_DEACTIVATE, 1f, 0.8f);
            } else {
                // devil aura: a dark outline cylinder around the body, refreshed every few ticks
                if (now % 6 == 0) FxSend.wall(sl, 1, p.position().add(0, 1.0, 0), new Vec3(1, 0, 0), new Vec3(0, 0, 1), 0.85f, 1.05f, -180, 180, 1.0f, 9, 0, 0);
                if (now % 12 == 0) FxSend.wall(sl, 0, p.position().add(0, 0.9, 0), new Vec3(1, 0, 0), new Vec3(0, 0, 1), 0.7f, 1.3f, -180, 180, 0.5f, 9, 0, 0);
                if (now % 4 == 0) burst(sl, BLACK, p.position().add(0, 1, 0), 2, 0.01, 0.45);
                if (now % 6 == 0) {
                    burst(sl, ParticleTypes.SOUL_FIRE_FLAME, p.position().add(0, p.getBbHeight() + 0.1, 0), 2, 0.02, 0.15);
                    burst(sl, ParticleTypes.LARGE_SMOKE, p.position().add(0, 0.2, 0), 1, 0.01, 0.3);
                }
            }
        }
    }

    /** Anti magic resistance: the swords cut incoming spells apart, and Devil Union nearly ignores them. */
    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || !(e.getSource() instanceof SpellDamageSource)) return;
        float keep;
        if (inDevilUnion(p)) keep = 1f - UNION_SPELL_RESIST;
        else if (holdsAntiMagicSword(p)) keep = 1f - SWORD_SPELL_RESIST;
        else return;
        e.setAmount(e.getAmount() * keep);
        burst(p.serverLevel(), BLACK, p.position().add(0, 1, 0), 12, 0.15, 0.4);
        sound(p.serverLevel(), p.position(), SoundEvents.ANVIL_LAND, 0.25f, 1.8f);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent e) {
        GUARD.clear();
        UNION.clear();
        LAST_COUNTER.clear();
        TASKS.clear();
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        GUARD.remove(e.getEntity().getUUID());
        UNION.remove(e.getEntity().getUUID());
        LAST_COUNTER.remove(e.getEntity().getUUID());
    }
}
