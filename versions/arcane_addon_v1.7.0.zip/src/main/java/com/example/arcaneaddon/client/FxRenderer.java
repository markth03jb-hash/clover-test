package com.example.arcaneaddon.client;

import com.example.arcaneaddon.network.FxPacket;
import com.example.arcaneaddon.registry.AddonItemRegistry;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource.BufferSource;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent.Stage;
import net.minecraftforge.event.TickEvent.ClientTickEvent;
import net.minecraftforge.event.TickEvent.Phase;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

@EventBusSubscriber(
   modid = "arcane_addon",
   value = {Dist.CLIENT}
)
public class FxRenderer {
   private static final ResourceLocation WHITE = ResourceLocation.fromNamespaceAndPath("arcane_addon", "textures/effect/white.png");
   private static final float[][] BODY = new float[][]{
      {0.06F, 0.0F, 0.04F},
      {0.03F, 0.0F, 0.08F},
      {0.22F, 0.05F, 0.0F},
      {0.02F, 0.1F, 0.16F},
      {0.12F, 0.11F, 0.0F},
      {0.04F, 0.13F, 0.09F},
      {0.07F, 0.07F, 0.09F}
   };
   private static final float[][] RIM = new float[][]{
      {1.0F, 0.16F, 0.24F}, {0.67F, 0.24F, 1.0F}, {1.0F, 0.6F, 0.12F}, {0.6F, 0.88F, 1.0F}, {1.0F, 0.96F, 0.44F}, {0.75F, 1.0F, 0.84F}, {0.95F, 0.95F, 1.0F}
   };
   /** Overall strength of every world effect. Lower = subtler. */
   private static final float FX_ALPHA = 0.85F;
   /** Effects closer than this to the camera fade out so they never cover the screen (first person). */
   private static final double NEAR_FADE_START = 0.8;
   private static final double NEAR_FADE_RANGE = 2.4;
   private static final float NEAR_FADE_MIN = 0.08F;
   private static boolean nearFade = false;
   private static double bookTime = 0.0;
   private static final List<FxRenderer.Fx> FX = new ArrayList<>();
   private static final List<FxRenderer.BookDraw> BOOKS = new ArrayList<>();
   private static final List<FxRenderer.AuraDraw> AURAS = new ArrayList<>();

   public static void queueBook(Vec3 pos, float yawS, float tiltDeg, float scale, float alpha, float flipCycle) {
      BOOKS.add(new FxRenderer.BookDraw(pos, yawS, tiltDeg, scale, alpha, flipCycle));
   }

   public static void queueAura(Vec3 a, Vec3 b, float width, int pal, float alpha) {
      AURAS.add(new FxRenderer.AuraDraw(a, b, width, pal, alpha));
   }

   public static void spawn(FxPacket p) {
      if (p.shape == 4) {   // Ki Sense mark: id = entity, palette = creature type, life = duration
         KiSenseRenderer.mark(p.id, p.palette, p.life);
         return;
      }
      if (p.shape == 5) {   // mid-move pose: id = player, palette = pose index
         ArcaneAnimations.play(p.id, p.palette);
         return;
      }
      Minecraft mc = Minecraft.getInstance();
      if (mc.level != null) {
         if (p.shape == 3) {
            for (FxRenderer.Fx f : FX) {
               if (f.p.id == p.id && f.killAge < 0.0) {
                  f.killAge = (double)mc.level.getGameTime() - f.born;
               }
            }
         } else {
            FxRenderer.Fx fx = new FxRenderer.Fx();
            fx.p = p;
            fx.born = (double)mc.level.getGameTime();
            FX.add(fx);
         }
      }
   }

   public static void localRing(Vec3 c, int pal, float r0, float r1, float h, int life) {
      FxPacket p = new FxPacket();
      p.shape = 0;
      p.palette = (byte)pal;
      p.life = life;
      p.c = c;
      p.d = new Vec3(1.0, 0.0, 0.0);
      p.u = new Vec3(0.0, 0.0, 1.0);
      p.r = r0;
      p.r2 = r1;
      p.a0 = -180.0F;
      p.a1 = 180.0F;
      p.h = h;
      spawn(p);
   }

   @SubscribeEvent
   public static void onTick(ClientTickEvent e) {
      if (e.phase == Phase.END) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.level == null) {
            FX.clear();
         } else {
            double now = (double)mc.level.getGameTime();
            Iterator<FxRenderer.Fx> it = FX.iterator();

            while (it.hasNext()) {
               FxRenderer.Fx f = it.next();
               double life = f.killAge >= 0.0 ? f.killAge + 4.0 : (double)f.p.life;
               if (now - f.born > life + 1.0) {
                  it.remove();
               }
            }
         }
      }
   }

   private static void vtx(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 cam, Vec3 w, float[] col, float a) {
      if (nearFade) {
         double d = w.distanceTo(cam);
         a *= Mth.clamp((float)((d - NEAR_FADE_START) / NEAR_FADE_RANGE), NEAR_FADE_MIN, 1.0F) * FX_ALPHA;
      }
      vc.vertex(m, (float)(w.x - cam.x), (float)(w.y - cam.y), (float)(w.z - cam.z))
         .color(col[0], col[1], col[2], Mth.clamp(a, 0.0F, 1.0F))
         .uv(0.5F, 0.5F)
         .overlayCoords(OverlayTexture.NO_OVERLAY)
         .uv2(15728880)
         .normal(n, 0.0F, 1.0F, 0.0F)
         .endVertex();
   }

   private static void quad(
      VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 cam, Vec3 a, Vec3 b, Vec3 c, Vec3 d, float[] col, float aa, float ab, float ac, float ad
   ) {
      vtx(vc, m, n, cam, a, col, aa);
      vtx(vc, m, n, cam, b, col, ab);
      vtx(vc, m, n, cam, c, col, ac);
      vtx(vc, m, n, cam, d, col, ad);
   }

   @SubscribeEvent
   public static void onRender(RenderLevelStageEvent e) {
      if (e.getStage() == Stage.AFTER_PARTICLES) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.level == null) {
            BOOKS.clear();
            AURAS.clear();
         } else {
            float pt = e.getPartialTick();
            PoseStack ps = e.getPoseStack();
            Vec3 cam = e.getCamera().getPosition();
            BufferSource buf = mc.renderBuffers().bufferSource();
            RenderType rt = RenderType.entityTranslucentEmissive(WHITE);
            VertexConsumer vc = buf.getBuffer(rt);
            double now = (double)((float)mc.level.getGameTime() + pt);
            Matrix4f m = ps.last().pose();
            Matrix3f n = ps.last().normal();
            nearFade = true;
            bookTime = now;

            for (FxRenderer.Fx f : FX) {
               double age = now - f.born;
               double life = f.killAge >= 0.0 ? f.killAge + 4.0 : (double)f.p.life;
               if (!(age < 0.0) && !(age > life)) {
                  float env = (float)(Mth.clamp(age / 1.5, 0.0, 1.0) * Mth.clamp((life - age) / Math.max(2.0, life * 0.45), 0.0, 1.0));
                  switch (f.p.shape) {
                     case 0:
                        wall(vc, m, n, cam, f.p, age, env);
                        break;
                     case 1:
                        crescentFx(vc, m, n, cam, f.p, age, env);
                        break;
                     case 2:
                        beam(vc, m, n, cam, f.p.c, f.p.c.add(f.p.d), f.p.r * (1.0F - 0.55F * (float)(age / life)), f.p.palette, env, 0.35);
                  }
               }
            }

            float pulse = 0.75F + 0.25F * (float)Math.sin(now * 0.35);

            for (Player p : mc.level.players()) {
               if (!p.isSpectator() && !p.isInvisible() && (p != mc.player || !mc.options.getCameraType().isFirstPerson())) {
                  heldAura(vc, m, n, cam, p, pt, pulse, p.getMainHandItem().getItem(), true);
                  heldAura(vc, m, n, cam, p, pt, pulse, p.getOffhandItem().getItem(), false);
               }
            }

            for (FxRenderer.AuraDraw a : AURAS) {
               beam(vc, m, n, cam, a.a, a.b, a.width, a.pal, a.alpha * pulse, 0.5);
            }

            AURAS.clear();
            nearFade = false;
            buf.endBatch(rt);
            if (!BOOKS.isEmpty()) {
               VertexConsumer bv = buf.getBuffer(rt);

               for (FxRenderer.BookDraw b : BOOKS) {
                  book(ps, bv, cam, b);
               }

               buf.endBatch(rt);
               BOOKS.clear();
            }
         }
      }
   }

   private static void heldAura(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 cam, Player p, float pt, float pulse, Item item, boolean main) {
      int pal;
      float len;
      float width;
      if (item == AddonItemRegistry.DEMON_SLAYER_SWORD.get()) {
         pal = 0;
         len = 3.0F;
         width = 0.34F;
      } else {
         if (item != AddonItemRegistry.DEMON_DWELLER_SWORD.get()) {
            return;
         }

         pal = 1;
         len = 2.1F;
         width = 0.24F;
      }

      double by = Math.toRadians((double)Mth.rotLerp(pt, p.yBodyRotO, p.yBodyRot));
      Vec3 fw = new Vec3(-Math.sin(by), 0.0, Math.cos(by));
      Vec3 lf = new Vec3(Math.cos(by), 0.0, Math.sin(by));
      boolean rightHand = p.getMainArm() == HumanoidArm.RIGHT == main;
      Vec3 base = new Vec3(
         Mth.lerp((double)pt, p.xo, p.getX()),
         Mth.lerp((double)pt, p.yo, p.getY()),
         Mth.lerp((double)pt, p.zo, p.getZ())
      );
      Vec3 hand = base.add(0.0, (double)p.getEyeHeight() * 0.62, 0.0).add(fw.scale(0.35)).add(lf.scale(rightHand ? -0.42 : 0.42));
      boolean dash = p.isAutoSpinAttack();
      Vec3 dir = dash ? p.getViewVector(pt).normalize() : fw.scale(0.5).add(0.0, 0.85, 0.0).normalize();
      // idle: a faint edge-glow along the blade; dashing: a stronger streak
      float a = (dash ? 0.9F : 0.4F) * pulse;
      beam(vc, m, n, cam, hand.subtract(dir.scale(0.25)), hand.add(dir.scale((double)len)), width * (dash ? 1.4F : 0.75F), pal, a, 0.5);
   }

   private static void wall(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 cam, FxPacket p, double age, float env) {
      double lifeFrac = Mth.clamp(age / (double)Math.max(1, p.life), 0.0, 1.0);
      float prog = p.sweep > 0 ? (float)Mth.clamp(age / (double)p.sweep, 0.0, 1.0) : 1.0F;
      prog = prog * prog * (3.0F - 2.0F * prog);
      float R = p.r + (p.r2 - p.r) * (float)lifeFrac;
      Vec3 c = p.c.add(p.d.scale((double)p.speed * age));
      Vec3 h = p.d.cross(p.u).normalize();
      float a0 = p.a0;
      float a1 = p.a0 + (p.a1 - p.a0) * prog;
      int segs = Math.max(4, (int)(Math.abs(a1 - a0) / 7.0F));
      float[] body = BODY[p.palette];
      float[] rim = RIM[p.palette];
      float[] mul = new float[]{0.92F, 1.0F, 1.09F};
      float[] am = new float[]{0.45F, 1.0F, 0.35F};

      for (int layer = 0; layer < 3; layer++) {
         double rl = (double)(R * mul[layer]);

         for (int i = 0; i < segs; i++) {
            double t0 = (double)i / (double)segs;
            double t1 = (double)(i + 1) / (double)segs;
            double th0 = Math.toRadians((double)a0 + (double)(a1 - a0) * t0);
            double th1 = Math.toRadians((double)a0 + (double)(a1 - a0) * t1);
            Vec3 p0 = c.add(p.d.scale(Math.cos(th0) * rl)).add(p.u.scale(Math.sin(th0) * rl));
            Vec3 p1 = c.add(p.d.scale(Math.cos(th1) * rl)).add(p.u.scale(Math.sin(th1) * rl));
            double hh0 = (double)p.h * (0.3 + 0.7 * Math.pow(Math.sin(Math.PI * (0.04 + 0.92 * t0)), 0.6));
            double hh1 = (double)p.h * (0.3 + 0.7 * Math.pow(Math.sin(Math.PI * (0.04 + 0.92 * t1)), 0.6));
            float lead0 = 0.45F + 0.55F * (float)t0;
            float lead1 = 0.45F + 0.55F * (float)t1;
            float A0 = 0.62F * env * am[layer] * lead0;
            float A1 = 0.62F * env * am[layer] * lead1;
            quad(vc, m, n, cam, p0.add(h.scale(hh0)), p1.add(h.scale(hh1)), p1, p0, body, 0.0F, 0.0F, A1, A0);
            quad(vc, m, n, cam, p0, p1, p1.subtract(h.scale(hh1)), p0.subtract(h.scale(hh0)), body, A0, A1, 0.0F, 0.0F);
            if (layer == 1) {
               double lw = (double)p.h * 0.05;
               quad(
                  vc,
                  m,
                  n,
                  cam,
                  p0.add(h.scale(lw)),
                  p1.add(h.scale(lw)),
                  p1.subtract(h.scale(lw)),
                  p0.subtract(h.scale(lw)),
                  rim,
                  0.95F * env * lead0,
                  0.95F * env * lead1,
                  0.95F * env * lead1,
                  0.95F * env * lead0
               );
            }
         }
      }

      for (int ix = 0; ix < segs; ix++) {
         double t0 = (double)ix / (double)segs;
         double t1 = (double)(ix + 1) / (double)segs;
         double th0 = Math.toRadians((double)a0 + (double)(a1 - a0) * t0);
         double th1 = Math.toRadians((double)a0 + (double)(a1 - a0) * t1);
         Vec3 p0 = c.add(p.d.scale(Math.cos(th0) * (double)R)).add(p.u.scale(Math.sin(th0) * (double)R));
         Vec3 p1 = c.add(p.d.scale(Math.cos(th1) * (double)R)).add(p.u.scale(Math.sin(th1) * (double)R));
         double hh0 = (double)p.h * (0.3 + 0.7 * Math.pow(Math.sin(Math.PI * (0.04 + 0.92 * t0)), 0.6));
         double hh1 = (double)p.h * (0.3 + 0.7 * Math.pow(Math.sin(Math.PI * (0.04 + 0.92 * t1)), 0.6));

         for (int sgn = -1; sgn <= 1; sgn += 2) {
            Vec3 e0 = p0.add(h.scale(hh0 * (double)sgn));
            Vec3 e1 = p1.add(h.scale(hh1 * (double)sgn));
            Vec3 i0 = p0.add(h.scale(hh0 * (double)sgn * 0.9));
            Vec3 i1 = p1.add(h.scale(hh1 * (double)sgn * 0.9));
            quad(vc, m, n, cam, e0, e1, i1, i0, rim, 0.55F * env, 0.55F * env, 0.1F * env, 0.1F * env);
         }
      }
   }

   private static void crescentFx(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 cam, FxPacket p, double age, float env) {
      double lifeFrac = Mth.clamp(age / (double)Math.max(1, p.life), 0.0, 1.0);
      float R = p.r + (p.r2 - p.r) * (float)lifeFrac;
      Vec3 c = p.c.add(p.d.scale((double)p.speed * age));
      Vec3 h = p.d.cross(p.u).normalize();

      for (int j = 0; j < 5; j++) {
         float a = env * (1.0F - 0.2F * (float)j);
         crescent(vc, m, n, cam, c.subtract(p.d.scale(0.55 * (double)j)), p.d, p.u, (double)(R * (1.0F - 0.09F * (float)j)), p.palette, a);
      }

      crescent(vc, m, n, cam, c.add(p.d.scale(0.05)), p.d, h, (double)(R * 0.5F), p.palette, env * 0.55F);
   }

   private static void crescent(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 cam, Vec3 c, Vec3 d, Vec3 u, double R, int pal, float env) {
      float[] body = BODY[pal];
      float[] rim = RIM[pal];
      int N = 16;

      for (int i = 0; i < N; i++) {
         double f0 = -78.0 + 156.0 * (double)i / (double)N;
         double f1 = -78.0 + 156.0 * (double)(i + 1) / (double)N;
         double r0 = Math.toRadians(f0);
         double r1 = Math.toRadians(f1);
         Vec3 o0 = c.add(u.scale(Math.sin(r0) * R)).add(d.scale((Math.cos(r0) - 1.0) * R * 0.55));
         Vec3 o1 = c.add(u.scale(Math.sin(r1) * R)).add(d.scale((Math.cos(r1) - 1.0) * R * 0.55));
         double t0 = 0.5 * R * Math.cos(Math.toRadians(f0 / 78.0 * 90.0));
         double t1 = 0.5 * R * Math.cos(Math.toRadians(f1 / 78.0 * 90.0));
         Vec3 i0 = o0.subtract(d.scale(t0));
         Vec3 i1 = o1.subtract(d.scale(t1));
         quad(vc, m, n, cam, o0, o1, i1, i0, body, 0.85F * env, 0.85F * env, 0.15F * env, 0.15F * env);
         double w0 = 0.09 * R * Math.cos(Math.toRadians(f0 / 78.0 * 90.0));
         double w1 = 0.09 * R * Math.cos(Math.toRadians(f1 / 78.0 * 90.0));
         quad(
            vc,
            m,
            n,
            cam,
            o0.add(d.scale(w0 * 0.3)),
            o1.add(d.scale(w1 * 0.3)),
            o1.subtract(d.scale(w1)),
            o0.subtract(d.scale(w0)),
            rim,
            0.98F * env,
            0.98F * env,
            0.7F * env,
            0.7F * env
         );
      }
   }

   private static void beam(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 cam, Vec3 p0, Vec3 p1, float width, int pal, float env, double endTaper) {
      Vec3 axis = p1.subtract(p0);
      double len = axis.length();
      if (!(len < 1.0E-4)) {
         Vec3 d = axis.scale(1.0 / len);
         Vec3 ref = Math.abs(d.y) > 0.95 ? new Vec3(1.0, 0.0, 0.0) : new Vec3(0.0, 1.0, 0.0);
         Vec3 n1 = d.cross(ref).normalize();
         Vec3 n2 = d.cross(n1).normalize();
         float[] body = BODY[pal];
         float[] rim = RIM[pal];
         int K = Math.max(4, Math.min(24, (int)(len * 2.0)));

         for (Vec3 nn : new Vec3[]{n1, n2}) {
            for (int k = 0; k < K; k++) {
               double t0 = (double)k / (double)K;
               double t1 = (double)(k + 1) / (double)K;
               double w0 = (double)width * Math.pow(Math.sin(Math.PI * (0.03 + 0.94 * t0)), endTaper);
               double w1 = (double)width * Math.pow(Math.sin(Math.PI * (0.03 + 0.94 * t1)), endTaper);
               Vec3 a = p0.add(axis.scale(t0));
               Vec3 b = p0.add(axis.scale(t1));
               float A = 0.7F * env;
               quad(vc, m, n, cam, a.add(nn.scale(w0)), b.add(nn.scale(w1)), b, a, body, 0.0F, 0.0F, A, A);
               quad(vc, m, n, cam, a, b, b.subtract(nn.scale(w1)), a.subtract(nn.scale(w0)), body, A, A, 0.0F, 0.0F);
               double cw0 = w0 * 0.12;
               double cw1 = w1 * 0.12;
               quad(
                  vc,
                  m,
                  n,
                  cam,
                  a.add(nn.scale(cw0)),
                  b.add(nn.scale(cw1)),
                  b.subtract(nn.scale(cw1)),
                  a.subtract(nn.scale(cw0)),
                  rim,
                  0.95F * env,
                  0.95F * env,
                  0.95F * env,
                  0.95F * env
               );
            }
         }
      }
   }

   private static void book(PoseStack ps, VertexConsumer vc, Vec3 cam, FxRenderer.BookDraw b) {
      ps.pushPose();
      ps.translate(b.pos.x - cam.x, b.pos.y - cam.y, b.pos.z - cam.z);
      ps.mulPose(Axis.YP.rotationDegrees(-b.yaw));
      ps.mulPose(Axis.YP.rotationDegrees(180.0F));
      ps.mulPose(Axis.XP.rotationDegrees(-b.tilt));
      ps.scale(b.scale, b.scale, b.scale);
      Matrix4f m = ps.last().pose();
      Matrix3f n = ps.last().normal();
      float HW = 0.5F;
      float HH = 0.36F;
      float V = (float)Math.toRadians(12.0);
      float al = b.alpha;

      for (int s = -1; s <= 1; s += 2) {
         float dx = (float)s * (float)Math.cos((double)V), dz = (float)Math.sin((double)V);
         panelOutline(vc, m, n, dx, dz, -0.004F, 0.5F, 0.36F, al, s);
         panel(vc, m, n, dx, dz, 0.0F, 0.5F, 0.36F, al);
      }

      if (b.flipCycle >= 0.0F) {
         for (int i = 0; i < 3; i++) {
            float sP = (b.flipCycle - (float)(4 + i * 5)) / 14.0F;
            if (!(sP <= 0.0F) && !(sP >= 1.0F)) {
               float mm = 0.5F - 0.5F * (float)Math.cos(Math.PI * (double)sP);
               double alpha = Math.toRadians((double)(-22.5F - 135.0F * mm));
               float lift = 0.015F * (1.0F - 2.0F * mm);
               panel(vc, m, n, (float)Math.cos(alpha), (float)(-Math.sin(alpha)), lift, 0.48F, 0.3456F, al * 0.9F);
            }
         }
      }

      ps.popPose();
   }

   private static void panel(VertexConsumer vc, Matrix4f m, Matrix3f n, float dx, float dz, float lift, float w, float h, float al) {
      float[] dark = new float[]{0.02F, 0.0F, 0.04F};
      float[] glow = new float[]{0.55F, 0.06F, 0.16F};
      float[] line = new float[]{0.05F, 0.0F, 0.08F};
      Vec3 a = pt(dx, dz, lift, 0.0F, -h);
      Vec3 b = pt(dx, dz, lift, w, -h);
      Vec3 c = pt(dx, dz, lift, w, h);
      Vec3 d = pt(dx, dz, lift, 0.0F, h);
      Vec3 z = Vec3.ZERO;
      quad(vc, m, n, z, a, b, c, d, dark, 0.16F * al, 0.16F * al, 0.16F * al, 0.16F * al);

      for (int i = 1; i <= 6; i++) {
         float y = -h + 2.0F * h * (float)i / 7.0F;
         float len = w * (i % 3 == 0 ? 0.55F : 0.82F);
         quad(
            vc,
            m,
            n,
            z,
            pt(dx, dz, lift, w * 0.1F, y - 0.006F),
            pt(dx, dz, lift, w * 0.1F + len, y - 0.006F),
            pt(dx, dz, lift, w * 0.1F + len, y + 0.006F),
            pt(dx, dz, lift, w * 0.1F, y + 0.006F),
            line,
            0.35F * al,
            0.35F * al,
            0.35F * al,
            0.35F * al
         );
      }

      float t = 0.028F;
      edge(vc, m, n, a, b, pt(dx, dz, lift, w, -h + t), pt(dx, dz, lift, 0.0F, -h + t), dark, al, glow);
      edge(vc, m, n, d, c, pt(dx, dz, lift, w, h - t), pt(dx, dz, lift, 0.0F, h - t), dark, al, glow);
      edge(vc, m, n, a, d, pt(dx, dz, lift, t, h), pt(dx, dz, lift, t, -h), dark, al, glow);
      edge(vc, m, n, b, c, pt(dx, dz, lift, w - t, h), pt(dx, dz, lift, w - t, -h), dark, al, glow);
   }

   /**
    * Black-flame outline around one open page: a soft dark-crimson halo hugging the outer three edges
    * (the spine edge is skipped), whose width flickers along its length like licking flame. Kept thin and
    * translucent so the book stays readable.
    */
   private static void panelOutline(VertexConsumer vc, Matrix4f m, Matrix3f n, float dx, float dz, float lift, float w, float h, float al, int seed) {
      float[] core = new float[]{0.42F, 0.03F, 0.08F};
      float[] smoke = new float[]{0.05F, 0.0F, 0.04F};
      // outer three edges as (start u,y) -> (end u,y) with outward normal (nu,ny); top edge gets taller flames
      float[][] edges = new float[][]{
         {0.0F, -h, w, -h, 0.0F, -1.0F, 0.7F},
         {w, -h, w, h, 1.0F, 0.0F, 1.0F},
         {w, h, 0.0F, h, 0.0F, 1.0F, 1.6F}
      };
      int N = 10;
      double t = bookTime * 0.22 + seed * 3.1;
      for (int e = 0; e < edges.length; e++) {
         float[] E = edges[e];
         for (int i = 0; i < N; i++) {
            float f0 = (float)i / N, f1 = (float)(i + 1) / N;
            float u0 = E[0] + (E[2] - E[0]) * f0, y0 = E[1] + (E[3] - E[1]) * f0;
            float u1 = E[0] + (E[2] - E[0]) * f1, y1 = E[1] + (E[3] - E[1]) * f1;
            int k0 = e * N + i, k1 = k0 + 1;
            float x0 = (float)(0.035 + 0.03 * Math.sin(t + k0 * 1.37) + 0.015 * Math.sin(t * 2.3 + k0 * 0.71)) * E[6];
            float x1 = (float)(0.035 + 0.03 * Math.sin(t + k1 * 1.37) + 0.015 * Math.sin(t * 2.3 + k1 * 0.71)) * E[6];
            x0 = Math.max(0.012F, x0);
            x1 = Math.max(0.012F, x1);
            Vec3 a = pt(dx, dz, lift, u0, y0), b = pt(dx, dz, lift, u1, y1);
            Vec3 ao = pt(dx, dz, lift, u0 + E[4] * x0, y0 + E[5] * x0), bo = pt(dx, dz, lift, u1 + E[4] * x1, y1 + E[5] * x1);
            Vec3 ao2 = pt(dx, dz, lift, u0 + E[4] * x0 * 1.9F, y0 + E[5] * x0 * 1.9F), bo2 = pt(dx, dz, lift, u1 + E[4] * x1 * 1.9F, y1 + E[5] * x1 * 1.9F);
            quad(vc, m, n, Vec3.ZERO, a, b, bo, ao, core, 0.55F * al, 0.55F * al, 0.12F * al, 0.12F * al);    // crimson inner glow
            quad(vc, m, n, Vec3.ZERO, ao, bo, bo2, ao2, smoke, 0.35F * al, 0.35F * al, 0.0F, 0.0F);          // dark smoky fringe
         }
      }
   }

   private static void edge(VertexConsumer vc, Matrix4f m, Matrix3f n, Vec3 o0, Vec3 o1, Vec3 i1, Vec3 i0, float[] dark, float al, float[] glow) {
      quad(vc, m, n, Vec3.ZERO, o0, o1, i1, i0, dark, 0.95F * al, 0.95F * al, 0.95F * al, 0.95F * al);
      quad(
         vc,
         m,
         n,
         Vec3.ZERO,
         i0,
         i1,
         i1.add(i1.subtract(o1).scale(0.25)),
         i0.add(i0.subtract(o0).scale(0.25)),
         glow,
         0.65F * al,
         0.65F * al,
         0.0F,
         0.0F
      );
   }

   private static Vec3 pt(float dx, float dz, float lift, float u, float y) {
      return new Vec3((double)(dx * u), (double)y, (double)(dz * u + lift));
   }

   private static record AuraDraw(Vec3 a, Vec3 b, float width, int pal, float alpha) {
   }

   private static record BookDraw(Vec3 pos, float yaw, float tilt, float scale, float alpha, float flipCycle) {
   }

   private static class Fx {
      FxPacket p;
      double born;
      double killAge = -1.0;
   }
}
