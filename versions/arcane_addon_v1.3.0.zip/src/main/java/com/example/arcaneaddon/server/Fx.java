package com.example.arcaneaddon.server;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Small effect vocabulary built ONLY from the addon's own 3D shapes (FxSend walls, rings, crescents, beams).
 * No vanilla particles are used anywhere in the addon.
 *
 * Palettes: 0 crimson (Slayer), 1 violet-black (Dweller / devil), 2 fire, 3 ice, 4 lightning, 5 wind, 6 white-silver.
 */
public final class Fx {
    private Fx() {}

    public static final int CRIMSON = 0, DARK = 1, FIRE = 2, ICE = 3, LIGHTNING = 4, WIND = 5, SILVER = 6;

    private static Vec3 randomUnit() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Vec3 v;
        do { v = new Vec3(r.nextDouble(-1, 1), r.nextDouble(-1, 1), r.nextDouble(-1, 1)); } while (v.lengthSqr() < 0.05 || v.lengthSqr() > 1);
        return v.normalize();
    }

    private static Vec3 perpendicular(Vec3 v) {
        Vec3 p = v.cross(new Vec3(0, 1, 0));
        if (p.lengthSqr() < 1.0E-4) p = v.cross(new Vec3(1, 0, 0));
        return p.normalize();
    }

    /** A sharp X of two thin blades plus a tilted flash ring: the standard "hit" mark. */
    public static void spark(ServerLevel sl, int pal, Vec3 c, float size) {
        Vec3 a = randomUnit();
        Vec3 b = perpendicular(a).scale(0.8).add(a.scale(0.2)).normalize();
        FxSend.beam(sl, pal, c.subtract(a.scale(size)), c.add(a.scale(size)), size * 0.16f, 5);
        FxSend.beam(sl, SILVER, c.subtract(b.scale(size * 0.8)), c.add(b.scale(size * 0.8)), size * 0.1f, 4);
        Vec3 n = randomUnit();
        FxSend.wall(sl, pal, c, perpendicular(n), n.cross(perpendicular(n)), size * 0.15f, size * 1.1f, -180, 180, size * 0.1f, 5, 0, 0);
    }

    /** A heavier hit: spark plus a horizontal shock ring. */
    public static void impact(ServerLevel sl, int pal, Vec3 c, float size) {
        spark(sl, pal, c, size);
        FxSend.ring(sl, pal, c, size * 0.2f, size * 1.8f, size * 0.2f, 7);
    }

    /** A quick white flash: two concentric rings that pop and vanish. */
    public static void flash(ServerLevel sl, Vec3 c, float size) {
        FxSend.ring(sl, SILVER, c, 0.05f, size, size * 0.4f, 3);
        FxSend.wall(sl, SILVER, c, new Vec3(1, 0, 0), new Vec3(0, 1, 0), 0.05f, size * 0.8f, -180, 180, size * 0.3f, 3, 0, 0);
    }

    /** A dust-free "puff" where something lands: a low wide ring. */
    public static void groundPuff(ServerLevel sl, int pal, Vec3 feet, float radius) {
        FxSend.ring(sl, pal, feet.add(0, 0.05, 0), radius * 0.2f, radius, 0.12f, 8);
    }

    /** A vertical column of energy. */
    public static void pillar(ServerLevel sl, int pal, Vec3 base, float height, float width, int life) {
        FxSend.beam(sl, pal, base, base.add(0, height, 0), width, life);
    }
}
